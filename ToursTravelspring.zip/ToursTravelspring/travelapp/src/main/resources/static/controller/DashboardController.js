travelApp.controller("dashboardController",function(){
	alert("dashboard Controller");
})