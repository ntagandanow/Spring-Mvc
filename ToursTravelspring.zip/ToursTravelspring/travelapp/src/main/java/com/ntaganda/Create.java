package com.ntaganda;

public interface Create {

}
