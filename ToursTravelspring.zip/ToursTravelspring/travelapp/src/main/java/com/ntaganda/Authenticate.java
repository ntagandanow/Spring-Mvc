package com.ntaganda;

public interface Authenticate {

}
